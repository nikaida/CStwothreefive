
#include "Robot.h"

Robot::Robot(std::string name, int maxHP, int strength, int speed, int magic):
    Fighter(name, maxHP, strength, speed, magic), 
    max_energy((Fighter::getMagic()) * MAGIC_MULTIPLIER),
    energy(max_energy),
    bonus_damage(0) {
}

int Robot::getDamage(){
    int damageDone = (Fighter::getStrength() + bonus_damage);
    int damage_dealt = damageDone;
    bonus_damage = 0;
    return damage_dealt;
}

void Robot::reset() {
    Fighter::reset();
    energy = max_energy;
    bonus_damage = 0;
}

bool Robot::useAbility() {
    if (energy >= ROBOT_ABILITY_COST) {
	    double anger = ((double)energy/max_energy);
            double pre_bonus_damage = (Fighter::getStrength() * pow((anger), ABILITY_EXPONENTIAL));
            bonus_damage = pre_bonus_damage;
	    energy -= ROBOT_ABILITY_COST; 
            return true;
    }
    else {
    return false;
    }
}




