
#ifndef CLERIC_H_
#define CLERIC_H_

#include "Fighter.h"


class Cleric : public Fighter {
    private:
        static const int MANA_INTEGER = 5;
        static const int ABILITY_MULTIPLIER = 3;
        static const int INCREASE_MIN = 1;

        int max_mana;
        int mana;
    public:
        Cleric(std::string name, int maxHP, int strength, int speed, int magic);
        int getDamage();
        void reset();
        void regenerate();
        bool useAbility();

};

#endif

