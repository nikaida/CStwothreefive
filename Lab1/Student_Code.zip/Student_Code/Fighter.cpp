#include "Fighter.h"

Fighter::Fighter(std::string name, int maxHP, int strength, int speed, int magic): 
    name(name), maxHP(maxHP), strength(strength), speed(speed), magic(magic) {
}

void Fighter::setStrength(int new_strength) {
    strength = new_strength;
}

void Fighter::setSpeed(int new_speed) {
    speed = new_speed;
}

void Fighter::setCurrentHP(int new_HP) {
    currentHP = new_HP;
}

std::string Fighter::getName() {
    return name;
}

int Fighter::getMaximumHP() {
    return maxHP;
}

int Fighter::getCurrentHP() {
    return currentHP;
}

int Fighter::getStrength() {
    return strength;
}

int Fighter::Fighter::getSpeed() {
    return speed;
}

int Fighter::getMagic() {
    return magic;
}

void Fighter::takeDamage(int damage_dealt) {
   int damage_taken = (damage_dealt - (speed/DAMAGE_DIVISOR));
    if (damage_taken < MINIMUM_DAMAGE) {
        damage_taken = 1;
    }
    currentHP -= damage_taken; 
    
}

void Fighter::reset() {
    currentHP = maxHP;
}

void Fighter::regenerate() {
    int bonus_HP = (strength/REGENERATION_MULTIPLIER);
    if (bonus_HP < MINIMUM_DAMAGE) {
        bonus_HP = MINIMUM_DAMAGE;
    }
    
    currentHP += bonus_HP;
    
    if (currentHP > maxHP) {
        currentHP = maxHP;
    }
}


